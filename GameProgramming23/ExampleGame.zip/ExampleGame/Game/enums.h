#pragma once


namespace MyEngine {

	enum GameObjectType { // WHERE TO PLACE THIS !!!! ???
		GENERIC, // this is just the GameObject class non derived
		PLAYER,
		METEOR,
		LAZER
	};
}